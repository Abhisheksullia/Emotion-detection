export const MeetingStatus = Object.freeze({
  Pending: "pending",
  Completed: "completed",
  Cancelled: "cancelled",
});
