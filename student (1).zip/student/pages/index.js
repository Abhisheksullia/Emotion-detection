import React from "react";

export default function Index() {
  return <div>Index</div>;
}

export async function getServerSideProps(context) {
  return {
    redirect: {
      permanent: false,
      destination: "/dashboard",
    },
  };
}
