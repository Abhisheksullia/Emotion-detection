import React, { useEffect, useState } from "react";
import DashboardCard from "../components/dashboard/card";
import MeetingCard from "../components/common/meetingCard";
import useHttp from "../hooks/useHttp";
import { useSelector } from "react-redux";
import { url } from "../store/actions/auth";
import LoaderRelative from "../components/common/loader";
import { BarChart } from "../components/dashboard/bar";
import { DoughnutChart } from "../components/dashboard/doughnut";
import Empty from "../components/common/empty";

export default function Dashboard() {
  const { isLoading, error, sendRequest: dashboardApi, setError } = useHttp();
  const token = useSelector((state) => state.auth.token);
  const [data, setData] = useState(null);
  useEffect(() => {
    dashboardApi(
      {
        url: `${url}/dashboard`,

        headers: { Authorization: `Bearer ${token}` },

        method: "GET",
      },
      (data) => {
        setData(data);
        console.log("data", data);
      }
    );
  }, []);
  return (
    <div className="baseClass ">
      {isLoading || !data ? (
        <div className="flex-1 flex flex-col justify-center items-center">
          <LoaderRelative />
        </div>
      ) : (
        <div className="flex-1 overflow-hidden flex gap-4">
          <div className=" flex-1 overflow-scroll space-y-4 no-scrollbar  ">
            <div className="flex self-start gap-6 ">
              <div className=" p-6 flex flex-col items-center px-8 w-92  bg-white  rounded-md">
                <h1 className=" mb-4 text-xl text-gray-500 font-medium ">
                  Total Meetings- {data.allMeeting}
                </h1>
                <div className="h-64 w-64">
                  <DoughnutChart
                    data={[
                      data.emotion?.["happy"] ?? 0,
                      data.emotion?.sad ?? 0,

                      data?.emotion?.surprise ?? 0,
                      data.emotion?.angry ?? 0,
                      data.emotion?.disgust ?? 0,
                      data.emotion?.neutral ?? 0,
                      data.emotion?.fear ?? 0,
                    ]}
                  />
                </div>
              </div>

              <div className="flex-1 p-6 flex flex-col items-center px-8 w-92 bg-white shadow-sm rounded-md">
                <h1 className=" mb-4 text-xl text-gray-500 font-medium ">
                  4 Month Report
                </h1>
                <div className="w-full flex items-center h-full">
                  <BarChart />
                </div>
              </div>
            </div>
            <div className="grid content-start bg-white rounded-md p-6 grid-cols-3 gap-10 gap-y-4">
              <h1 className="col-span-4 text-lg ">Total Logs</h1>
              <DashboardCard label="Meeting Joined" value={data.allMeeting} />
              <DashboardCard
                label="Avg Emotion"
                value={data.allEmotion ?? "None"}
              />
              <DashboardCard
                label="Avg Drowsy"
                value={data.allDrowsy ?? "None"}
              />
              <h1 className="col-span-4 mt-8 text-lg">Todays Logs</h1>
              <DashboardCard label="Meeting Joined" value={data.todayMeeting} />
              <DashboardCard
                label="Avg Emotion"
                value={data.todayEmotion ?? "None"}
              />
              <DashboardCard
                label="Avg Drowsy"
                value={data.todayDrowsy ?? "None"}
              />
            </div>
          </div>
          <div className="bg-white overflow-hidden space-y-6  w-88 flex flex-col rounded-md px-4 py-4">
            <h1 className="text-lg">Pending Meetings</h1>
            {data.meetings.length == 0 ? (
              <div className="overflow-y-scroll flex-1 flex flex-col justify-center no-scrollbar">
                <Empty height="h-72" />
                <h1 className="text-center text-xl">No Pending Meetings</h1>
              </div>
            ) : (
              <div className="space-y-4 flex-1 overflow-scroll no-scrollbar">
                {data.meetings.map((value) => (
                  <MeetingCard value={value} />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
