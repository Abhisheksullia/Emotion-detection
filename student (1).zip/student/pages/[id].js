import React, { useState, useEffect, useRef } from "react";
import { useSelector } from "react-redux";

import { url } from "../store/actions/auth";
import { useRouter } from "next/router";
import axios from "axios";
import Phone from "../components/icons/outline/phone";

const VideoCallCard = () => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const { token } = useSelector((state) => state.auth);
  const router = useRouter(null);
  const [isCapturing, setIsCapturing] = useState(false);
  let stream;

  useEffect(() => {
    if (router.isReady) {
      const startCapture = async () => {
        try {
          const res = await axios({
            method: "put",
            url: `${url}/join/meeting`,
            data: { meetingId: router.query.id },
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });

          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
          });

          videoRef.current.srcObject = stream;
          setIsCapturing(true);
        } catch (error) {
          console.error("Error accessing camera", error);
          router.replace("/dashboard");
        }
      };

      startCapture();
      return () => {
        const tracks = stream?.getTracks() ?? [];
        tracks?.forEach((track) => {
          track?.stop();
        });
      };
    }
  }, [router.isReady]);

  useEffect(() => {
    if (canvasRef.current) {
      // Update canvas height when the component is rendered or canvasRef.current changes
      canvasRef.current.height = 150;
      canvasRef.current.width = 150;
    }
  }, []);

  //In this function we send image snapshot to our api every 5 minutes
  useEffect(() => {
    let intervalId;

    if (isCapturing) {
      intervalId = setInterval(async () => {
        const canvas = canvasRef.current;
        const video = videoRef.current;
        const canvasHeight = canvasRef.current.height;
        console.log("Canvas height:", canvasHeight);

        if (canvas && video) {
          //here we draw video image on canvas(html5)
          const ctx = canvas.getContext("2d");
          ctx.drawImage(video, 0, 0, 224, 224);

          //after drawing that image we convert canvas image to base64 image
          const base64ImageData = canvas.toDataURL("image/png", 0.4);

          try {
            // we send this base64 image to out main backend api
            const response = await axios({
              method: "post",
              url: `${url}/add/log`,
              data: { meetingId: router.query.id, image: base64ImageData },
              headers: {
                Authorization: `Bearer ${token}`,
              },
            });
          } catch (err) {
            console.log(err);
          }
        }
      }, 10000); // Capture every 5 minutes
    }

    return () => clearInterval(intervalId);
  }, [isCapturing]);

  return (
    <div>
      <video
        className="w-screen h-screen"
        ref={videoRef}
        autoPlay
        playsInline
      />
      <canvas ref={canvasRef} className="h-80 w-80 hidden" />
      <div
        onClick={() => {
          router.back();
        }}
        className="bg-primary absolute items-center left-1/2 -translate-x-1/2 rounded-md  cursor-pointer z-50 bottom-6 text-white flex gap-2 px-4 py-2"
      >
        <Phone className="h-5 w-5 text-white" />
        <h1>Leave Meeting</h1>
      </div>
    </div>
  );
};

export default VideoCallCard;
