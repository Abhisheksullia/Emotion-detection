import React, { useEffect, useState } from "react";
import MeetingCard from "../components/common/meetingCard";
import MeetingHeader from "../components/meeting/meetingHeader";
import DetailMeetingHeader from "../components/meeting/meetingHeader";
import DetailMeetingCard from "../components/meeting/meetingCard";
import EmotionCard from "../components/meeting/emotionCard";
import useHttp from "../hooks/useHttp";
import { useSelector } from "react-redux";
import { url } from "../store/actions/auth";
import LoaderRelative from "../components/common/loader";
import { MeetingStatus } from "../enum";
import { useRouter } from "next/router";
import { toast } from "react-toastify";
import Empty from "../components/common/empty";
import moment from "moment";

export default function Meeting() {
  const router = useRouter(null);
  const [selected, setSelected] = useState(null);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const { isLoading, error, sendRequest: dashboardApi, setError } = useHttp();
  const token = useSelector((state) => state.auth.token);
  const [data, setData] = useState(null);
  useEffect(() => {
    dashboardApi(
      {
        url: `${url}/meetings`,

        headers: { Authorization: `Bearer ${token}` },

        method: "GET",
      },
      (data) => {
        setData(data);
        if (data.length > 0) {
          setSelectedIndex(0);
          setSelected(data[0]);
        }
        console.log("data", data);
      }
    );
  }, []);
  return (
    <div className="baseClass ">
      {isLoading || !data ? (
        <div className="flex-1 flex flex-col justify-center items-center">
          <LoaderRelative />
        </div>
      ) : (
        <div className="flex-1 overflow-hidden flex gap-4">
          <div className="bg-white flex-1 py-2  rounded-md flex overflow-hidden flex-col">
            <MeetingHeader />
            {data.length == 0 ? (
              <div className="overflow-y-scroll flex-1 flex flex-col justify-center no-scrollbar">
                <Empty />
                <h1 className="text-center text-xl">No Meeting Added yet</h1>
              </div>
            ) : (
              <div className="flex-1 overflow-y-scroll no-scrollbar">
                {data.map((value, index) => (
                  <DetailMeetingCard
                    value={value}
                    onClick={() => {
                      setSelectedIndex(index);
                      setSelected(value);
                    }}
                    selected={selectedIndex == index}
                    even={index % 2 == 0}
                  />
                ))}
              </div>
            )}
          </div>
          <div className="bg-white overflow-hidden space-y-6  w-88 flex flex-col rounded-md px-4 py-4">
            <div className="flex gap-4 items-center w-full ">
              <h1 className="flex-1 ">Emotions Timeline</h1>
              {selected && (
                <div className="flex">
                  <h2
                    onClick={(e) => {
                      e.stopPropagation();
                      if (selected.status == MeetingStatus.Pending) {
                        if (
                          moment()
                            .add(2, "minutes")
                            .isAfter(moment(selected.startTime))
                        ) {
                          router.push(`/${selected.meetingLink}`);
                        } else {
                          toast.error(
                            "you can only join meeting before 2 mins"
                          );
                        }
                      } else {
                        toast.error("This meeting is cancelled by teacher");
                      }
                    }}
                    className={`py-1.5 ${
                      selected.status == MeetingStatus.Pending &&
                      moment()
                        .add(2, "minutes")
                        .isAfter(moment(selected.startTime))
                        ? "bg-opacity-80"
                        : "bg-opacity-40"
                    }  px-4 bg-secondary cursor-pointer  text-white rounded-md text-sm`}
                  >
                    {selected.status == MeetingStatus.Pending
                      ? "Join now"
                      : selected.status}
                  </h2>
                </div>
              )}
            </div>
            {selected?.logs.length == 0 ? (
              <div className="overflow-y-scroll flex-1 flex flex-col justify-center no-scrollbar">
                <Empty height="h-72" />
                <h1 className="text-center text-xl">No Emotion Timeline yet</h1>
              </div>
            ) : (
              <div className="space-y-4 flex-1 overflow-scroll no-scrollbar">
                {selected?.logs.map((value, index) => (
                  <EmotionCard value={value} />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
