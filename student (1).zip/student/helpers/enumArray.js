const convertEnumToArray = (values) => {
  return Object.values(values)
}

export default convertEnumToArray
