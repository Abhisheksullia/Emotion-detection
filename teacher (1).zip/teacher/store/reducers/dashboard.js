import { createSlice } from "@reduxjs/toolkit";
import { HYDRATE } from "next-redux-wrapper";

const dashboardSlice = createSlice({
  name: "dashboard",
  initialState: {
    data: null,
  },
  reducers: {
    setData(state, { payload }) {
      state.data = payload;
    },
    updateMeetingStatus(state, { payload }) {
      try {
        state.data.meetings[payload.index].status = payload.status;
      } catch (err) {}
    },
    addMeeting(state, { payload }) {
      if (state.data) {
        state.data.meetings = [payload, ...state.data.meetings];
      }
    },
  },
  extraReducers: {
    [HYDRATE]: (state, action) => {
      return {
        ...state,
        ...action.payload.dashboard,
      };
    },
  },
});

export const dashboardActions = dashboardSlice.actions;

export default dashboardSlice.reducer;
