import { createSlice } from "@reduxjs/toolkit";
import { HYDRATE } from "next-redux-wrapper";

const authSlice = createSlice({
  name: "auth",
  initialState: {
    token: null,
    isLoggedIn: false,
    username: null,

    user: null,

    forgotNumber: null,
  },
  reducers: {
    login(state, action) {
      state.isLoggedIn = true;
      state.user = action?.payload?.user;

      state.username = action.payload?.username;

      state.token = action.payload?.token;
    },
    logout(state, action) {
      return {
        token: null,
        isLoggedIn: false,
        user: null,
      };
    },
    setForgotNumber(state, action) {
      state.forgotNumber = action.payload;
    },
  },
  extraReducers: {
    [HYDRATE]: (state, action) => {
      return {
        ...state,
        ...action.payload.auth,
      };
    },
  },
});

export const authActions = authSlice.actions;

export default authSlice.reducer;
