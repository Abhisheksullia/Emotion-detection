import { authActions } from "../reducers/auth";

import axios from "axios";
import router from "next/router";

export const url = "http://localhost:4000/teacher";

export const signUp = (body) => {
  return async (dispatch) => {
    try {
      const response = await axios({
        method: "post",
        url: `${url}/signup`,
        data: body,
      });
      dispatch(
        authenticate({
          token: response.data.token,
          isLoggedIn: !!response.data.token,

          user: response?.data?.user,
          username: response.data.user.username,
        })
      );

      router.replace("/dashboard");
      saveDataToStorage(response.data.token);
    } catch (err) {
      console.log(err);
      throw err;
    }
  };
};

export const forgot = async (username) => {
  try {
    const response = await axios({
      method: "post",
      url: `${url}/forgot/number`,
      data: { username },
    });
  } catch (err) {
    console.log(err);

    throw err;
  }
};

export const forgotVerify = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${url}/forgot/verify/number`,
      data: payload,
    });
  } catch (err) {
    throw err;
  }
};

export const authenticate = (values) => {
  return (dispatch) => {
    dispatch(authActions.login(values));
  };
};

export const login = (password, username) => {
  return async (dispatch) => {
    let bodyJsonData = { password, username };
    try {
      let response = await axios({
        method: "post",
        url: `${url}/login`,
        data: bodyJsonData,
        withCredentials: true,
      });
      console.log("resonse", response.data);
      dispatch(
        authenticate({
          token: response.data.token,
          isLoggedIn: !!response.data.token,
          user: response?.data?.user,

          username: response.data.user.username,
        })
      );

      await router.push("/dashboard");

      saveDataToStorage(response.data.token);
    } catch (err) {
      console.log("err", err);
      throw err;
    }
  };
};

export const logout = (token) => {
  return async (dispatch) => {
    await axios.post(
      `${url}/logout`,
      {},
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    dispatch(authActions.logout());
    router.push("/auth/login");
    clearStorage();
  };
};

export const clearStorage = () => {
  try {
    localStorage.removeItem("token");
  } catch (err) {}
};

const saveDataToStorage = (token, number, username, profileUri) => {
  localStorage.setItem("token", token);
};
