export const MeetingType = Object.freeze({
  Instant: "instant",
  Schedule: "schedule",
});

export const MeetingStatus = Object.freeze({
  Pending: "pending",
  Completed: "completed",
  Cancelled: "cancelled",
});
