import React, { Fragment, useState } from "react";
import * as Yup from "yup";
import { Formik } from "formik";
import { signUp, url } from "../../../store/actions/auth";
import { useRouter } from "next/router";
import { useDispatch } from "react-redux";
import Link from "next/link";
import AuthSide from "../../../components/common/authSide";
import AuthHeader from "../../../components/common/authHeader";
import { AuthInputWithLogo } from "../../../components/common/authInput";
import Popup from "../../../components/common/popup";
import ExclamationIcon from "../../../components/icons/outline/exclamationIcon";
import { Logo } from "../../../components/layout/header";

export const passwordRegexp =
  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;

const SignupSchema = Yup.object().shape({
  username: Yup.string().min(8).required("Name is required"),
  password: Yup.string()
    .matches(
      passwordRegexp,
      "Password length must be more than 8 characters and contain at least 1 capital letter, 1 number and one special character."
    )
    .required("Required"),
});

function Signup() {
  const router = useRouter();

  const [error, setError] = useState(false);
  const dispatch = useDispatch(null);

  return (
    <Fragment>
      {error && (
        <Popup
          onPressAnyOption={() => setError(null)}
          message={error}
          title="Wrong Input"
          okMessage="Ok"
          cancelMessage="Cancel"
          Icon={ExclamationIcon}
          show={false}
        />
      )}
      <div className="h-screen border-2 bg-white  md:flex  ">
        <AuthSide />
        <div className="md:order-2 pl-2 md:flex md:h-full  md:flex-1 md:flex-col md:bg-white ">
          <Logo size="text-base mt-2" />
          <div className="md:order-2 md:flex  md:flex-1 md:flex-col md:justify-center ">
            <AuthHeader
              title="Register for Teacher"
              subTitle="Create your new account"
            />

            <Formik
              initialValues={{
                password: "",
                username: "",
              }}
              validationSchema={SignupSchema}
              onSubmit={async (values, { setSubmitting }) => {
                try {
                  await dispatch(
                    signUp({
                      password: values.password,
                      username: values.username,
                    })
                  );

                  router.replace({
                    pathname: "/",
                  });
                } catch (err) {
                  setSubmitting(false);
                  console.log(err);
                  setError(
                    err?.response?.data?.message ?? "Something went Wrong"
                  );
                }
              }}
            >
              {({
                values,
                errors,
                touched,

                handleChange,
                handleBlur,
                handleSubmit,
                isSubmitting,
                /* and other goodies */
              }) => (
                <form
                  onSubmit={handleSubmit}
                  className="mt-6 px-4 md:mx-auto  md:w-2/3"
                >
                  <div className="space-y-4 md:space-y-8">
                    <AuthInputWithLogo
                      name="username"
                      label="Name"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      errors={errors}
                      touched={touched}
                      value={values.username}
                    />

                    <AuthInputWithLogo
                      type="password"
                      name="password"
                      label="Password"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      errors={errors}
                      touched={touched}
                      value={values.password}
                    />
                  </div>

                  <button
                    className=" mt-8 flex h-10 w-full flex-col items-center justify-center rounded-lg bg-secondary  font-semibold text-white shadow-xl focus:outline-none "
                    type="submit"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <div className=" flex items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-gray-900"></div>
                      </div>
                    ) : (
                      "Proceed"
                    )}
                  </button>
                  <h3 className="mt-2 text-center text-xs font-extralight text-secondaryText md:text-base">
                    Already have an account?{" "}
                    <Link href="/auth/login">
                      <span className="cursor-pointer text-primary underline ">
                        Login
                      </span>
                    </Link>
                  </h3>
                </form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </Fragment>
  );
}

export default Signup;
