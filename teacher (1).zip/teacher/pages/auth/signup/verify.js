import React, { Fragment, useRef, useState } from "react";

import { useRouter } from "next/router";
import { useDispatch, useSelector } from "react-redux";

import AuthSide from "../../../components/common/authSide";
import AuthHeader from "../../../components/common/authHeader";

import Popup from "../../../components/common/popup";
import ExclamationIcon from "../../../components/icons/outline/exclamationIcon";
import { Logo } from "../../../components/layout/header";

import axios from "axios";
import { toast, ToastContainer } from "react-toastify";

import "react-toastify/dist/ReactToastify.css";
import OtpVerification from "../../../components/common/otpVerification";
import { verify } from "../../../store/actions/auth";

function Signup() {
  const router = useRouter();
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const webToken = useSelector((store) => store.auth.webToken);
  const dispatch = useDispatch();
  const one = useRef(null);
  const [isSubmitting, setSubmitting] = useState(false);
  const two = useRef(null);
  const three = useRef(null);
  const four = useRef(null);

  const onChangeEvent = (e, ref, blur = false) => {
    if (e.target.value.length == 1 && !blur) {
      ref.current.focus();
    }
    if (e.target.value.length == 1 && blur) {
      ref.current.blur();
    }
    console.log(e.target.value);
  };

  async function onSubmit(value) {
    console.log("value", value);
    setSubmitting(true);
    try {
      // if (!webToken) {
      //   setError("please turn on the notification");
      //   return;
      // }
      await dispatch(verify(value, router.query.number, webToken));
      router.replace("/");
    } catch (err) {
      setSubmitting(false);
      console.log("err", err);
      setError(err?.response?.data?.message ?? "Something went Wrong");
    }
  }

  return (
    <Fragment>
      {error && (
        <Popup
          onPressAnyOption={() => setError(null)}
          message={error}
          title="Wrong Input"
          okMessage="Ok"
          cancelMessage="Cancel"
          Icon={ExclamationIcon}
          show={false}
        />
      )}
      <div className="h-screen border-2 bg-white  md:flex  ">
        <AuthSide />
        <div className="md:order-2 pl-2 md:flex md:h-full  md:flex-1 md:flex-col md:bg-white ">
          <Logo size="text-base mt-2" />
          <div className="md:order-2 md:flex  md:flex-1 md:flex-col md:justify-center ">
            <AuthHeader
              title="Register for Admin"
              subTitle="Verify your Account"
            />

            <form className="mt-6 px-4 md:mx-auto  md:w-2/3">
              <OtpVerification
                firstRef={one}
                isSubmitting={isSubmitting}
                secondRef={two}
                thirdRef={three}
                fourthRef={four}
                onChangeEvent={onChangeEvent}
                verifyHandler={onSubmit}
                backHandler={() => {
                  router.back();
                }}
              />

              <div className="mt-2 px-8 text-center text-sm">
                <span>Didn't receive the OTP? </span>
                <span
                  className="text-primary"
                  onClick={async () => {
                    try {
                      console.log("tap");

                      await axios({
                        method: "post",
                        url: `/api/auth/resend`,
                        data: { number: router.query.number },
                      });
                      toast.success(
                        `We have resent OTP on ${router.query.number}`,
                        {
                          position: toast.POSITION.BOTTOM_CENTER,
                        }
                      );
                    } catch (err) {
                      console.log(err);
                      setError("Something went wrong");
                    }
                  }}
                >
                  Resend
                </span>
              </div>
            </form>
          </div>
        </div>
      </div>
      <ToastContainer
        autoClose={2000}
        pauseOnFocusLoss={false}
        pauseOnHover={false}
      />
    </Fragment>
  );
}

export default Signup;
