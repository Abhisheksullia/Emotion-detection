import React, { useRef, useState } from "react";
import { useRouter } from "next/router";
import { useDispatch, useSelector } from "react-redux";
import * as Yup from "yup";
import { Formik } from "formik";
import { login } from "../../store/actions/auth";
import Link from "next/link";

import Popup from "../../components/common/popup";
import ExclamationIcon from "../../components/icons/outline/exclamationIcon";

import AuthSide from "../../components/common/authSide";
import { AuthInputWithLogo } from "../../components/common/authInput";

import AuthHeader from "../../components/common/authHeader";
import { Logo } from "../../components/layout/header";
import { passwordRegexp } from "./signup";

const phoneRegExp = /^[6-9]\d{9}$/;

const SigninSchema = Yup.object().shape({
  password: Yup.string()
    .matches(
      passwordRegexp,
      "Password length must be more than 8 characters and contain at least 1 capital letter, 1 number and one special character."
    )
    .required("Required"),
  username: Yup.string().min(8).required("Name is required"),
});

export default function Login({}) {
  const dispatch = useDispatch();
  const router = useRouter();

  const [error, setError] = useState(null);

  return (
    <div className="h-screen border-2 bg-white  md:flex  ">
      <AuthSide />
      <div className="md:order-2 pl-2 pt-2  md:flex md:h-full  md:flex-1 md:flex-col md:bg-white ">
        <Logo size="text-base mt-2" />
        <div className="md:order-2 md:flex  md:flex-1 md:flex-col md:justify-center ">
          <AuthHeader title="Welcome Teacher" />
          <Formik
            initialValues={{ username: "", password: "" }}
            validationSchema={SigninSchema}
            onSubmit={async (values, { setSubmitting }) => {
              try {
                await dispatch(login(values.password, values.username));
                console.log("after dispatch");
                setSubmitting(false);
                router.replace("/");
              } catch (err) {
                console.log(err);
                setError(
                  err?.response?.data?.message ?? "Something went Wrong"
                );
              }
            }}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleBlur,
              handleSubmit,
              isSubmitting,
              /* and other goodies */
            }) => (
              <form
                onSubmit={handleSubmit}
                className="mt-6 px-4 md:mx-auto  md:w-2/3"
              >
                {error && (
                  <Popup
                    onPressAnyOption={() => {
                      setError(null);
                    }}
                    message={error}
                    title="Bad Request"
                    okMessage="Ok"
                    cancelMessage="Cancel"
                    Icon={ExclamationIcon}
                    show={false}
                  />
                )}
                <div className="space-y-5 md:space-y-8">
                  <AuthInputWithLogo
                    name="username"
                    label="User Name"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    errors={errors}
                    touched={touched}
                    value={values.username}
                  />

                  <AuthInputWithLogo
                    type="password"
                    name="password"
                    label="Password"
                    onChange={handleChange}
                    errors={errors}
                    touched={touched}
                    onBlur={handleBlur}
                    value={values.password}
                  />
                </div>

                {/* <Link href="/auth/forgot/number">
                  <div className="mb-8 mt-2 cursor-pointer text-right text-sm text-primary underline ">
                    Forgot Password?
                  </div>
                </Link> */}
                <button
                  className=" flex mt-8 h-10 w-full flex-col items-center justify-center rounded-lg bg-secondary  font-semibold text-white shadow-xl focus:outline-none "
                  type="submit"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <div className=" flex items-center justify-center">
                      <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-gray-900"></div>
                    </div>
                  ) : (
                    "Proceed"
                  )}
                </button>
                <h3 className="mt-2 text-center text-xs font-extralight text-secondaryText md:text-base">
                  Don't have an account ?{" "}
                  <Link href="/auth/signup">
                    <span className="cursor-pointer text-primary underline ">
                      Create an account
                    </span>
                  </Link>
                </h3>
              </form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
}
