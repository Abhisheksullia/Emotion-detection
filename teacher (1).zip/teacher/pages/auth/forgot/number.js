import React, { Fragment, ReactElement, useState } from "react";
import { Formik } from "formik";
import * as Yup from "yup";

import Link from "next/link";
import { useRouter } from "next/dist/client/router";

import Popup from "../../../components/common/popup";
import { useDispatch, useSelector } from "react-redux";

import { forgot } from "../../../store/actions/auth";
import ExclamationIcon from "../../../components/icons/outline/exclamationIcon";

import { AuthInputWithLogo } from "../../../components/common/authInput";
import AuthHeader from "../../../components/common/authHeader";
import { Logo } from "../../../components/layout/header";
import AuthSide from "../../../components/common/authSide";

const phoneRegExp = /^(\+91[\-\s]?)?[0]?(91)?[789]\d{9}$/;

const SigninSchema = Yup.object().shape({
  number: Yup.string()
    .matches(phoneRegExp, "Phone number is not valid")
    .required("Required"),
});

export default function NumberPage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const [error, setError] = useState(null);

  return (
    <Fragment>
      {error && (
        <Popup
          onPressAnyOption={() => setError(null)}
          message={error}
          title="Wrong Input"
          okMessage="Ok"
          cancelMessage="Cancel"
          Icon={ExclamationIcon}
          show={false}
        />
      )}
      <div className="h-screen   border-2 bg-white flex ">
        <AuthSide />
        <div className="md:order-2 pl-2 pt-2  md:flex md:h-full  md:flex-1 md:flex-col md:bg-white ">
          <Logo size="text-base mt-2" />
          <div className="md:order-2 md:flex  md:flex-1 md:flex-col md:justify-center ">
            <AuthHeader
              title="Reset Password"
              subTitle="Input your login number"
            />
            <Formik
              initialValues={{ number: "" }}
              validationSchema={SigninSchema}
              onSubmit={async (values, { setSubmitting }) => {
                try {
                  await forgot(values.number);

                  router.push({
                    pathname: "/auth/forgot/verify",
                    query: { number: values.number },
                  });
                } catch (err) {
                  setError(
                    err?.response?.data?.message ?? "Something went Wrong"
                  );
                }
              }}
            >
              {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                handleSubmit,
                isSubmitting,
                /* and other goodies */
              }) => (
                <form
                  onSubmit={handleSubmit}
                  className="mt-6 px-4 md:mx-auto  md:w-2/3"
                >
                  <div className="space-y-5 md:space-y-8">
                    <AuthInputWithLogo
                      type="number"
                      name="number"
                      label="Phone Number"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      errors={errors}
                      touched={touched}
                      value={values.number}
                    />

                    <button
                      className=" flex h-10 w-full flex-col items-center justify-center rounded-lg bg-gradient  font-semibold text-white shadow-xl focus:outline-none "
                      type="submit"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <div className=" flex items-center justify-center">
                          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-gray-900"></div>
                        </div>
                      ) : (
                        "Proceed"
                      )}
                    </button>
                  </div>
                  <div className="mt-2 text-right">
                    Don't have an account?
                    <Link href="/auth/signup">
                      <span className="cursor-pointer text-primary">
                        {" "}
                        Register
                      </span>
                    </Link>
                  </div>
                </form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </Fragment>
  );
}
