// @ts-nocheck
import React, { Fragment, useRef } from "react";
import * as Yup from "yup";
import { Formik } from "formik";
import { useRouter } from "next/router";
import { useState } from "react";

import ExclamationIcon from "../../../components/icons/outline/exclamationIcon";
import Popup from "../../../components/common/popup";
import { forgotVerify } from "../../../store/actions/auth";

import { OtpInput } from "../../../components/common/otpVerification";
import Image from "next/image";
import { useDispatch, useSelector } from "react-redux";
import { passwordRegexp } from "../signup";
import { AuthInputWithLogo } from "../../../components/common/authInput";
import AuthHeader from "../../../components/common/authHeader";
import AuthSide from "../../../components/common/authSide";
import { Logo } from "../../../components/layout/header";

const VerifySchema = Yup.object().shape({
  password: Yup.string()
    .matches(
      passwordRegexp,
      "Password length must be more than 8 characters and contains at least 1 capital letter,1 number and one special character"
    )
    .required("Required"),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("password"), null], "Passwords must match")
    .required("Required"),
});

function Verify() {
  const one = useRef(null);
  const two = useRef(null);
  const three = useRef(null);
  const four = useRef(null);
  const dispatch = useDispatch(null);

  const router = useRouter();
  const [error, setError] = useState(null);

  const [success, setSuccess] = useState(false);

  const onChangeEventHandler = (e, ref, blur = false) => {
    if (e.target.value.length == 1 && !blur) {
      ref.current.focus();
    }
    if (e.target.value.length == 1 && blur) {
      ref.current.blur();
    }
    console.log(e.target.value);
  };

  function onSubmitHandler() {
    console.log("hello");

    if (
      one.current.value &&
      two.current.value &&
      three.current.value &&
      four.current.value
    ) {
      let value = `${one.current.value}${two.current.value}${three.current.value}${four.current.value}`;
      return value;
    } else {
      if (!one.current.value) {
        one.current.focus();
      } else if (!two.current.value) {
        two.current.focus();
      } else if (!three.current.value) {
        three.current.focus();
      } else if (!four.current.value) {
        four.current.focus();
      }
      return false;
    }
  }

  return (
    <div className="h-screen border-2 bg-white  md:flex  ">
      <AuthSide />
      <div className="md:order-2 pl-2 pt-2  md:flex md:h-full  md:flex-1 md:flex-col md:bg-white ">
        <Logo size="text-base mt-2" />
        <div className="md:order-2 md:flex  md:flex-1 md:flex-col md:justify-center ">
          <AuthHeader
            title="Verify Phone Number"
            subTitle="Change your password."
          />

          <Formik
            initialValues={{
              password: "",
              confirmPassword: "",
            }}
            validationSchema={VerifySchema}
            onSubmit={async (values, { setSubmitting }) => {
              try {
                const value = onSubmitHandler();
                if (value == false) {
                  return;
                } else {
                  await forgotVerify({
                    code: value,
                    number: router.query.number,
                    password: values.confirmPassword,
                  });
                }
                setSuccess("Your password has been reset");
                setSubmitting(false);
              } catch (err) {
                setError(
                  err?.response?.data?.message ?? "Something Went wrong"
                );
              }
            }}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleBlur,
              handleSubmit,
              isSubmitting,
              /* and other goodies */
            }) => (
              <form
                onSubmit={handleSubmit}
                className="mt-6 px-4 md:mx-auto  md:w-2/3"
              >
                {error && (
                  <Popup
                    onPressAnyOption={() => {
                      setError(null);
                    }}
                    message={error}
                    title="Oops sorry"
                    okMessage="Ok"
                    cancelMessage="Cancel"
                    Icon={ExclamationIcon}
                    show="false"
                  />
                )}
                {success && (
                  <Popup
                    onPressAnyOption={() => {
                      router.replace("/auth/login");
                    }}
                    message={success}
                    title="Go to Login Page"
                    okMessage="Ok"
                    show={false}
                    cancelMessage="Cancel"
                    Icon={ExclamationIcon}
                  />
                )}
                <div className="mt-6 space-y-8 px-4">
                  <AuthInputWithLogo
                    type="password"
                    name="password"
                    label="Password"
                    onChange={handleChange}
                    errors={errors}
                    touched={touched}
                    onBlur={handleBlur}
                    value={values.password}
                  />
                  <AuthInputWithLogo
                    type="password"
                    name="confirmPassword"
                    label="Confirm Password"
                    onChange={handleChange}
                    errors={errors}
                    touched={touched}
                    onBlur={handleBlur}
                    value={values.confirmPassword}
                  />
                  <div className="space-y-1">
                    <h1 className="ml-1 text-sm text-black text-opacity-60">
                      Verify Otp
                    </h1>
                    <div className="flex space-x-2">
                      <OtpInput
                        name="1"
                        size={12}
                        refs={one}
                        onChange={(e) => {
                          onChangeEventHandler(e, two);
                        }}
                      />
                      <OtpInput
                        name="2"
                        size={12}
                        refs={two}
                        onChange={(e) => {
                          onChangeEventHandler(e, three);
                        }}
                      />
                      <OtpInput
                        name="3"
                        size={12}
                        refs={three}
                        onChange={(e) => {
                          onChangeEventHandler(e, four);
                        }}
                      />
                      <OtpInput
                        name="4"
                        size={12}
                        refs={four}
                        onChange={(e) => {
                          onChangeEventHandler(e, four, true);
                        }}
                      />
                    </div>
                  </div>
                </div>
                <div className="mt-8 px-4">
                  <button
                    className=" flex h-10 w-full flex-col items-center justify-center rounded-lg bg-gradient  font-semibold text-white shadow-xl focus:outline-none "
                    type="submit"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <div className=" flex items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-gray-900"></div>
                      </div>
                    ) : (
                      "Proceed"
                    )}
                  </button>
                </div>
              </form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
}

export default Verify;
