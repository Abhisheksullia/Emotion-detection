import React, { useEffect, useState } from "react";
import MeetingCard from "../components/common/meetingCard";
import MeetingHeader from "../components/meeting/meetingHeader";
import DetailMeetingHeader from "../components/meeting/meetingHeader";
import DetailMeetingCard from "../components/meeting/meetingCard";
import EmotionCard from "../components/meeting/emotionCard";
import StudentCard from "../components/meeting/studentCard";
import BackdropLayout from "../components/higherOrder/backdropLayout";
import useHttp from "../hooks/useHttp";
import { useSelector } from "react-redux";
import LoaderRelative from "../components/common/loader";
import { url } from "../store/actions/auth";
import axios from "axios";
import { MeetingStatus } from "../enum";
import moment from "moment";
import Empty from "../components/common/empty";

export default function Meeting() {
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(null);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const { isLoading, error, sendRequest: dashboardApi, setError } = useHttp();
  const token = useSelector((state) => state.auth.token);
  const [data, setData] = useState(null);
  const [logs, setLogs] = useState(null);
  const [showEmotion, setShowEmotion] = useState(false);
  const [meetingDetail, setMeetingDetail] = useState(null);
  useEffect(() => {
    dashboardApi(
      {
        url: `${url}/meetings`,

        headers: { Authorization: `Bearer ${token}` },

        method: "GET",
      },
      async (data) => {
        setData(data);
        if (data.length > 0) {
          setSelectedIndex(0);
          setSelected(data[0]);
          data?.[0]?._id && selectMeetingHandler(0, data[0]._id);
        }
        console.log("data", data);
      }
    );
  }, []);

  let cancelRequest;

  async function selectMeetingHandler(index, id) {
    cancelRequest && cancelRequest();
    const CancelToken = axios.CancelToken;

    try {
      console.log("hello");
      setLoading(true);

      const response = await axios.get(`${url}/meeting/users/${id}`, {
        cancelToken: new CancelToken(function executor(c) {
          cancelRequest = c;
        }),
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setLoading(false);
      setMeetingDetail(response.data);
    } catch (err) {
      console.log(err);
      setLoading(false);
      setMeetingDetail(null);
      if (axios.isCancel(err)) {
        console.log("cancel old get command");
      }
    }
  }

  return (
    <div className="baseClass ">
      {isLoading || !data ? (
        <div className="flex-1 flex flex-col justify-center items-center">
          <LoaderRelative />
        </div>
      ) : (
        <div className="flex-1 overflow-hidden flex gap-4">
          <div className="bg-white flex-1 py-2  rounded-md flex overflow-hidden flex-col">
            <MeetingHeader />
            {data.length == 0 ? (
              <div className="overflow-y-scroll flex-1 flex flex-col justify-center no-scrollbar">
                <Empty />
                <h1 className="text-center text-xl">No Meeting Added yet</h1>
              </div>
            ) : (
              <div className="flex-1 overflow-y-scroll no-scrollbar">
                {data.map((value, index) => (
                  <DetailMeetingCard
                    cancelHandler={(status) => {
                      setData((data) => [
                        ...data.slice(0, index),
                        {
                          ...data[index],
                          status,
                          ...(status == MeetingStatus.Completed
                            ? { endTime: moment().toDate() }
                            : {}),
                        },
                        ...data.slice(index + 1),
                      ]);
                    }}
                    onClick={() => {
                      setSelectedIndex(index);
                      setSelected(value);
                      selectMeetingHandler(index, value._id);
                    }}
                    value={value}
                    selected={index == selectedIndex}
                    even={index % 2 == 0}
                  />
                ))}
              </div>
            )}
          </div>
          <div className="bg-white overflow-hidden space-y-6  w-88 flex flex-col rounded-md px-4 py-4">
            <h1 className="text-lg">User Joined</h1>
            {loading || !meetingDetail ? (
              <div className="flex-1 flex flex-col justify-center items-center">
                <LoaderRelative />
              </div>
            ) : meetingDetail.length == 0 ? (
              <div className="overflow-y-scroll flex-1 flex flex-col justify-center no-scrollbar">
                <Empty height="h-60" />
                <h1 className="text-center text-xl">No User Joined</h1>
              </div>
            ) : (
              <div className="space-y-4 flex-1 overflow-scroll no-scrollbar">
                {meetingDetail.map((value, index) => (
                  <StudentCard
                    onClick={() => {
                      setShowEmotion(true);
                      setLogs(value.logs);
                    }}
                    value={value}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      {showEmotion && (
        <BackdropLayout
          cancelPopup={() => {
            setShowEmotion(false);
          }}
        >
          <div className="popupClass w-2/3 max-w-md h-2/3 p-6 bg-white rounded-md">
            <div className="bg-white flex-1 overflow-hidden space-y-6  flex flex-col rounded-md ">
              <h1 className="text-lg">Emotions Timeline</h1>
              <div className="space-y-4 flex-1 overflow-scroll no-scrollbar">
                {logs.map((value, index) => (
                  <EmotionCard value={value} />
                ))}
              </div>
            </div>
          </div>
        </BackdropLayout>
      )}
    </div>
  );
}
