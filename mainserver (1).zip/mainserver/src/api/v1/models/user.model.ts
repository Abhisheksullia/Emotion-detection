import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

import UserType from "../interfaces/userType";
import BaseIdentifier from "../interfaces/baseIdentifier";
import convertEnumToArray from "../helpers/enumArray";

export interface UserDocument extends mongoose.Document, BaseIdentifier {
  username: string;
  type: UserType;
  password: string;

  generateAuthToken(): Promise<string>;
}

var UserSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    type: {
      type: String,
      default: UserType.Student,
      enum: convertEnumToArray(UserType),
    },

    password: {
      type: String,
      required: true,
      unique: true,
    },

    tokens: [String],
  },
  {
    timestamps: true,
  }
);

UserSchema.methods.comparePassword = async function (
  candidatePassword: string
): Promise<Boolean> {
  const user = this as UserDocument;
  return bcrypt.compare(candidatePassword, user.password);
};

UserSchema.methods.generateAuthToken = async function (): Promise<string> {
  const user = this as UserDocument;
  const token = jwt.sign({ _id: user._id }, process.env.JWT_SECRET as string);

  user.tokens.push(token);

  await user.save();
  return token;
};

UserSchema.methods.toJSON = function () {
  const user = this as UserDocument;
  const userObject = user.toObject() as any;

  delete userObject.password;
  delete userObject.tokens;

  return userObject;
};

UserSchema.pre(
  "save",
  async function (
    this: UserDocument,
    next: mongoose.CallbackWithoutResultAndOptionalError
  ) {
    const user = this;
    if (user.isModified("password")) {
      user.password = await bcrypt.hash(user.password, 8);
    }
    next();
  }
);

export const User = mongoose.model<UserDocument>("User", UserSchema);
