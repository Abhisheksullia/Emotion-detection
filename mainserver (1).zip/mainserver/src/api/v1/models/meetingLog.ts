import mongoose, { Schema } from "mongoose";

export interface MeetingLogDocument extends mongoose.Document {
  emotion: string;
  meetingId: mongoose.Types.ObjectId;
  userId: mongoose.Types.ObjectId;
  createdAt: Date;
  drowsiness: string;
}

const MeetingLogSchema = new Schema(
  {
    meetingId: {
      type: mongoose.Types.ObjectId,
      ref: "User",
      required: true,
    },
    drowsiness: { type: String },
    userId: { type: mongoose.Types.ObjectId, ref: "User", required: true },
    emotion: { type: String, required: true },
  },
  { timestamps: true }
);

export const MeetingLog = mongoose.model<MeetingLogDocument>(
  "MeetingLog",
  MeetingLogSchema
);
