import mongoose, { Schema } from "mongoose";
import MeetingStatus from "../enums/status";
import convertEnumToArray from "../helpers/enumArray";

export interface MeetingDocument extends mongoose.Document {
  endTime?: Date;
  title?: string;
  users: mongoose.Types.ObjectId[];
  meetingLink: string;
  createdBy: mongoose.Types.ObjectId;
  startTime: Date;
  status: MeetingStatus;
}

const userSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Types.ObjectId, ref: "User" },
  },
  { _id: false, timestamps: true }
);

const MeetingSchema = new Schema(
  {
    startTime: { type: Date, required: true },
    endTime: { type: Date },
    title: String,
    users: [mongoose.Types.ObjectId],
    status: {
      type: String,
      enum: convertEnumToArray(MeetingStatus),
      default: MeetingStatus.Pending,
    },
    meetingLink: { type: String, required: true },
    createdBy: { type: mongoose.Types.ObjectId, required: true },
  },
  { timestamps: true }
);

export const Meeting = mongoose.model<MeetingDocument>(
  "Meeting",
  MeetingSchema
);
