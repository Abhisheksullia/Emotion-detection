import { Request } from "express";
import tf, { loadLayersModel, node, div, sub } from "@tensorflow/tfjs-node";
import sharp from "sharp";
import path from "path";

async function loadEmotionAndGiveResponse(image: tf.Tensor): Promise<number> {
  const model = await loadLayersModel(
    `file://${path.join(__dirname, "./model/model.json")}`
  );
  const output = model.predict(image);
  //@ts-ignore
  output.print();
  //@ts-ignore
  const values = output.dataSync();

  // Get the array of values from the tensor
  const maxValue = Math.max(...values); // Find the maximum value
  const maxIndex = values.indexOf(maxValue); // Find the index of the maximum value
  console.log("maxIndex", maxIndex);
  return maxIndex;
}

async function loadDrowsinessAndGiveResponse(
  image: tf.Tensor
): Promise<number> {
  const model = await loadLayersModel(
    `file://${path.join(__dirname, "./drowsinessModel/model.json")}`
  );
  const output = model.predict(image);
  //@ts-ignore
  output.print();
  //@ts-ignore
  const values = output.dataSync();

  // Get the array of values from the tensor
  const maxValue = Math.max(...values); // Find the maximum value
  const maxIndex = values.indexOf(maxValue); // Find the index of the maximum value
  console.log("maxIndex", maxIndex, values);
  return maxIndex;
}

export async function detectEmotionAndDrowsiness(req: Request) {
  let buffer: Buffer | undefined;
  try {
    const base64Data = req.body.image.replace(/^data:image\/png;base64,/, ""); // Remove the data URL prefix

    // Convert base64 data to a Buffer
    buffer = Buffer.from(base64Data, "base64");
  } catch (err) {
    console.log("error", err);
  }
  if (!buffer) {
    return null;
  }

  const image = await sharp(buffer)
    .resize(224, 224)
    .toColorspace("srgb")
    .toFormat("jpg")
    .toBuffer();
  const tensor = node.decodeImage(image, 0);
  const expandedTensor = tensor.expandDims();
  const normalizedTensor = sub(div(expandedTensor, 127.5), 1);

  const emotionIndex = await loadEmotionAndGiveResponse(normalizedTensor);
  const drowsinessIndex = await loadDrowsinessAndGiveResponse(normalizedTensor);
  return { emotionIndex, drowsinessIndex };
}
