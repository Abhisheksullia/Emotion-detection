export default function findMaxKey(obj: { [key: string]: number }) {
  let maxKey = null;
  let maxValue = -Infinity;

  for (const key in obj) {
    if (obj.hasOwnProperty(key) && obj[key] > maxValue) {
      maxValue = obj[key];
      maxKey = key;
    }
  }
  return maxKey;
}
