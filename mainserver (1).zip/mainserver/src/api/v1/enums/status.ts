enum MeetingStatus {
  Cancelled = "cancelled",
  Completed = "completed",
  "Pending" = "pending",
}
export default MeetingStatus;
