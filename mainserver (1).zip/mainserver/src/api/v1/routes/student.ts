import express from "express";
import authRequired from "../middleware/auth";
import UserType from "../interfaces/userType";
import {
  createStudentHandler,
  dashboardHandler,
  getStatusHandler,
  joinMeetingHandler,
  loginStudentHandler,
  logoutStudentHandler,
  meetingDetail,
  meetingLogHandler,
} from "../controllers/student";
import { User } from "../models/user.model";

const StudentRouter = express.Router();

StudentRouter.post("/signup", createStudentHandler);

StudentRouter.post("/login", loginStudentHandler);
StudentRouter.post("/logout", logoutStudentHandler);

StudentRouter.post(
  "/add/log",
  authRequired(User, UserType.Student),
  meetingLogHandler
);

StudentRouter.put(
  "/join/meeting",
  authRequired(User, UserType.Student),
  joinMeetingHandler
);

StudentRouter.get(
  "/status",
  authRequired(User, UserType.Student),
  getStatusHandler
);

StudentRouter.get(
  "/dashboard",
  authRequired(User, UserType.Student),
  dashboardHandler
);

StudentRouter.get(
  "/meetings",
  authRequired(User, UserType.Student),
  meetingDetail
);

export default StudentRouter;
