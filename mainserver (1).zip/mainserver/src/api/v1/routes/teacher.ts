import express from "express";
import {
  cancelMeetingHandler,
  createMeetingHandler,
  createTeacherHandler,
  dashboardHandler,
  endMeetingHandler,
  getStatusHandler,
  loginTeacherHandler,
  logoutTeacherHandler,
  meetingDetail,
  meetingUserDetail,
} from "../controllers/admin";
import authRequired from "../middleware/auth";
import { User } from "../models/user.model";
import UserType from "../interfaces/userType";

const TeacherRouter = express.Router();

TeacherRouter.post("/signup", createTeacherHandler);

TeacherRouter.post("/login", loginTeacherHandler);
TeacherRouter.post("/logout", logoutTeacherHandler);

TeacherRouter.get(
  "/status",
  authRequired(User, UserType.Teacher),
  getStatusHandler
);

TeacherRouter.get(
  "/dashboard",
  authRequired(User, UserType.Teacher),
  dashboardHandler
);

TeacherRouter.post(
  "/create/meeting",
  authRequired(User, UserType.Teacher),
  createMeetingHandler
);

TeacherRouter.put(
  "/end/meeting/:meetingId",
  authRequired(User, UserType.Teacher),
  endMeetingHandler
);
TeacherRouter.put(
  "/cancel/meeting/:meetingId",
  authRequired(User, UserType.Teacher),
  cancelMeetingHandler
);

TeacherRouter.get(
  "/meetings",
  authRequired(User, UserType.Teacher),
  meetingDetail
);
TeacherRouter.get(
  "/meeting/users/:meetingId",
  authRequired(User, UserType.Teacher),
  meetingUserDetail
);
export default TeacherRouter;
