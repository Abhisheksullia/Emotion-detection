import {
  FilterQuery,
  UpdateQuery,
  QueryOptions,
  PipelineStage,
} from "mongoose";
import { MeetingLogDocument, MeetingLog } from "../models/meetingLog";

export async function createMeetingLog(input: any) {
  return MeetingLog.create(input);
}

export async function findMeetingLog(
  query: FilterQuery<MeetingLogDocument>,
  select: { [key: string]: number } = {},
  options: QueryOptions = {}
) {
  return MeetingLog.findOne(query, select, options);
}

export async function findAllMeetingLog(
  query: FilterQuery<MeetingLogDocument>,
  select: { [key: string]: number } = {},
  options: QueryOptions = {}
) {
  return MeetingLog.find(query, select, options);
}

export async function findAndUpdateMeetingLog(
  query: FilterQuery<MeetingLogDocument>,
  update: UpdateQuery<MeetingLogDocument>,
  options: QueryOptions
) {
  return MeetingLog.findOneAndUpdate(query, update, options);
}

export async function deletePost(query: FilterQuery<MeetingLogDocument>) {
  return MeetingLog.deleteOne(query);
}

export async function aggregateMeetingLog(operators: PipelineStage[]) {
  return MeetingLog.aggregate(operators);
}
