import {
  FilterQuery,
  UpdateQuery,
  QueryOptions,
  PipelineStage,
} from "mongoose";
import { UserDocument, User } from "../models/user.model";
import UserType from "../interfaces/userType";

export async function createUser(input: any) {
  return User.create(input);
}

export async function findUser(
  query: FilterQuery<UserDocument>,
  select: { [key: string]: number } = {},
  options: QueryOptions = {}
) {
  return User.findOne(query, select, options);
}

export async function findAllUser(
  query: FilterQuery<UserDocument>,
  select: { [key: string]: number } = {},
  options: QueryOptions = {}
) {
  return User.find(query, select, options);
}

export async function validatePassword({
  username,
  password,
  type,
}: {
  username: string;
  password: string;
  type: UserType;
}) {
  try {
    const user = await User.findOne({ username, type });

    if (!user) {
      return false;
    }

    const isValid = await user.comparePassword(password);
    console.log(User, password, isValid);
    if (!isValid) {
      return false;
    }

    return user;
  } catch (err) {
    console.log(err);
  }
}

export async function findAndUpdateUser(
  query: FilterQuery<UserDocument>,
  update: UpdateQuery<UserDocument>,
  options: QueryOptions
) {
  return User.findOneAndUpdate(query, update, options);
}

export async function deletePost(query: FilterQuery<UserDocument>) {
  return User.deleteOne(query);
}

export async function aggregateUser(operators: PipelineStage[]) {
  return User.aggregate(operators);
}
