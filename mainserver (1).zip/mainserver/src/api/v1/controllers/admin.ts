import {
  aggregateUser,
  createUser,
  findAndUpdateUser,
  findUser,
  validatePassword,
} from "../services/user.service";
import shortid from "shortid";
import { Request, Response } from "express";
import checkError from "../helpers/checkErrors";
import CustomError from "../helpers/customError";
import UserType from "../interfaces/userType";
import jwt from "jsonwebtoken";
import CustomJwtPayload from "../interfaces/jwtPayload";
import {
  aggregateMeeting,
  createMeeting,
  findAllMeeting,
  findAndUpdateMeeting,
  findMeeting,
} from "../services/meeting.service";
import { UserDocument } from "../models/user.model";
import moment from "moment";
import MeetingStatus from "../enums/status";
import findMaxKey from "../helpers/maxkey";
import { Meeting } from "../models/meeting";

export async function createTeacherHandler(req: Request, res: Response) {
  try {
    const code = Math.round(Math.random() * 8999 + 1000);
    const username = req.body.username as string;

    const admin = await findUser({ username, type: UserType.Teacher });
    if (admin) {
      throw new CustomError("Bad Request", 404, "Teacher already exist");
    }

    const user = await createUser({
      ...req.body,
      type: UserType.Teacher,
    });
    const token = await user.generateAuthToken();

    res.status(200).send({ user, token });
  } catch (err) {
    checkError(err, res);
  }
}

export async function loginTeacherHandler(req: Request, res: Response) {
  try {
    const admin = await validatePassword({
      ...req.body,
      type: UserType.Teacher,
    });
    if (!admin) {
      throw new CustomError(
        "Bad request",
        404,
        "Please Provide Right Credientials"
      );
    }
    const token = await admin.generateAuthToken();

    // res.cookie("jwt", "manish", { httpOnly: true });
    console.log({ user: admin, token });
    res.send({ user: admin, token });
  } catch (err) {
    checkError(err, res);
  }
}

export async function logoutTeacherHandler(req: Request, res: Response) {
  try {
    const token = req.header("Authorization")?.replace("Bearer ", "") as string;
    console.log("token", token);
    if (!token) {
      throw new CustomError("Bad request", 401, "Please Authenticate first");
    }
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET as string
    ) as CustomJwtPayload;
    const admin = findAndUpdateUser(
      {
        _id: decoded._id,
        tokens: token,
      },
      {
        $pull: {
          tokens: token,
        },
      },
      {}
    );

    if (!admin) {
      throw new CustomError("Bad request", 401, "Please Authenticate first");
    }

    res.send({ message: "You are successfully logout" });
  } catch (err) {
    checkError(err, res);
  }
}

export async function getStatusHandler(req: Request, res: Response) {
  try {
    res.send(req.user);
  } catch (err) {
    checkError(err, res);
  }
}

export async function createMeetingHandler(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;
    // const meeting=await Meeting.create({})
    const meeting = await createMeeting({
      ...req.body,
      createdBy: user._id,
      meetingLink: shortid.generate(),
    });
    res.send({ link: meeting.meetingLink });
  } catch (err) {
    checkError(err, res);
  }
}

export async function cancelMeetingHandler(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;
    const meetings = await findAndUpdateMeeting(
      {
        meetingLink: req.params.meetingId,
        startTime: { $gt: moment().toDate() },
        createdBy: user._id,
      },
      { $set: { status: MeetingStatus.Cancelled } },
      {}
    );
    res.send({ message: "meeting successfully cancelled" });
  } catch (err) {
    checkError(err, res);
  }
}

export async function endMeetingHandler(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;
    const meetings = await findAndUpdateMeeting(
      {
        meetingLink: req.params.meetingId,
        startTime: { $lte: moment().toDate() },
        createdBy: user._id,
      },
      { $set: { status: MeetingStatus.Completed, endTime: moment().toDate() } },
      {}
    );
    res.send({ message: "meeting successfully completed" });
  } catch (err) {
    checkError(err, res);
  }
}

export async function dashboardHandler(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;
    const meetings = await findAllMeeting({
      startTime: { $gt: moment().subtract(10, "minute").toDate() },
      createdBy: user._id,
    });
    const todaysMeetings = await aggregateMeeting([
      {
        $match: {
          createdBy: user._id,
          startTime: {
            $gte: moment().startOf("day").toDate(),
            $lt: moment().endOf("day").toDate(),
          },
        },
      },
      {
        $lookup: {
          from: "meetinglogs",
          let: { meetingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [{ $eq: ["$meetingId", "$$meetingId"] }],
                },
              },
            },
          ],
          as: "logs",
        },
      },
    ]);
    const report = { emotion: {}, drowsy: {} };
    todaysMeetings.forEach((value) => {
      const exp = (value.logs as any[]).reduce(
        (total, value) => {
          if (total.emotion[value.emotion]) {
            total.emotion[value.emotion] += 1;
          } else {
            total.emotion[value.emotion] = 1;
          }
          if (total.drowsy[value.drowsiness]) {
            total.drowsy[value.drowsiness] += 1;
          } else {
            total.drowsy[value.drowsiness] = 1;
          }
          return total;
        },
        {
          emotion: {},
          drowsy: {},
        }
      );
      const drowsy = findMaxKey(exp.drowsy);
      const emotion = findMaxKey(exp.emotion);
      if (emotion) {
        //@ts-ignore
        if (report.emotion[emotion]) {
          //@ts-ignore
          report.emotion[emotion] += 1;
        } else {
          //@ts-ignore
          report.emotion[emotion] = 1;
        }
      }
      if (drowsy) {
        //@ts-ignore
        if (report.drowsy[drowsy]) {
          //@ts-ignore
          report.drowsy[drowsy] += 1;
        } else {
          //@ts-ignore
          report.drowsy[drowsy] = 1;
        }
      }
    });
    const allMeetings = await aggregateMeeting([
      {
        $match: {
          createdBy: user._id,
        },
      },
      { $sort: { startTime: -1 } },
      {
        $lookup: {
          from: "meetinglogs",
          let: { meetingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [{ $eq: ["$meetingId", "$$meetingId"] }],
                },
              },
            },
          ],
          as: "logs",
        },
      },
    ]);
    const reportAll = { emotion: {}, drowsy: {} };
    allMeetings.forEach((value) => {
      const exp = (value.logs as any[]).reduce(
        (total, value) => {
          if (total.emotion[value.emotion]) {
            total.emotion[value.emotion] += 1;
          } else {
            total.emotion[value.emotion] = 1;
          }
          if (total.drowsy[value.drowsiness]) {
            total.drowsy[value.drowsiness] += 1;
          } else {
            total.drowsy[value.drowsiness] = 1;
          }
          return total;
        },
        {
          emotion: {},
          drowsy: {},
        }
      );
      const drowsy = findMaxKey(exp.drowsy);
      const emotion = findMaxKey(exp.emotion);
      if (emotion) {
        //@ts-ignore
        if (reportAll.emotion[emotion]) {
          //@ts-ignore
          reportAll.emotion[emotion] += 1;
        } else {
          //@ts-ignore
          reportAll.emotion[emotion] = 1;
        }
      }
      if (drowsy) {
        //@ts-ignore
        if (reportAll.drowsy[drowsy]) {
          //@ts-ignore
          reportAll.drowsy[drowsy] += 1;
        } else {
          //@ts-ignore
          reportAll.drowsy[drowsy] = 1;
        }
      }
    });
    console.log("report", report, reportAll);
    res.send({
      meetings,
      emotion: reportAll.emotion,
      allMeeting: allMeetings.length,
      allEmotion: findMaxKey(reportAll.emotion),
      allDrowsy: findMaxKey(reportAll.drowsy),
      todayMeeting: todaysMeetings.length,
      todayEmotion: findMaxKey(report.emotion),
      todayDrowsy: findMaxKey(report.drowsy),
    });
  } catch (err) {
    checkError(err, res);
  }
}

export async function meetingDetail(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;

    const meetings = await aggregateMeeting([
      {
        $match: {
          createdBy: user._id,
        },
      },
      { $sort: { startTime: -1 } },
      {
        $lookup: {
          from: "meetinglogs",
          let: { meetingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [{ $eq: ["$meetingId", "$$meetingId"] }],
                },
              },
            },
          ],
          as: "logs",
        },
      },
    ]);
    res.send(meetings);
  } catch (err) {
    checkError(err, res);
  }
}

export async function meetingUserDetail(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;
    console.log("req", req.params.meetingId);
    const meeting = await findMeeting(
      { _id: req.params.meetingId, createdBy: user._id },
      { users: 1 }
    );
    if (!meeting) {
      throw new CustomError("Bad Request", 404, "No such meeting found");
    }

    const users = await aggregateUser([
      {
        $match: {
          _id: { $in: meeting.users },
        },
      },
      {
        $lookup: {
          from: "meetinglogs",
          let: { userId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$meetingId", meeting._id] },
                    { $eq: ["$userId", "$$userId"] },
                  ],
                },
              },
            },
          ],
          as: "logs",
        },
      },
    ]);
    console.log("users", users);
    res.send(users);
  } catch (err) {
    checkError(err, res);
  }
}
