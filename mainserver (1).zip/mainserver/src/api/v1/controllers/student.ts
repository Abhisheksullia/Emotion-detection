import {
  createUser,
  findAndUpdateUser,
  findUser,
  validatePassword,
} from "../services/user.service";
import { Request, Response } from "express";
import checkError from "../helpers/checkErrors";
import CustomError from "../helpers/customError";
import UserType from "../interfaces/userType";
import jwt from "jsonwebtoken";
import CustomJwtPayload from "../interfaces/jwtPayload";
import { UserDocument } from "../models/user.model";
import {
  aggregateMeeting,
  findAllMeeting,
  findAndUpdateMeeting,
  findMeeting,
} from "../services/meeting.service";
import moment from "moment";
import { createMeetingLog } from "../services/meetingLog.service";
import MeetingStatus from "../enums/status";
import findMaxKey from "../helpers/maxkey";
import { detectEmotionAndDrowsiness } from "../helpers/detectEmotion";

export async function createStudentHandler(req: Request, res: Response) {
  try {
    console.log("body", req.body);
    const username = req.body.username as string;

    const admin = await findUser({ username, type: UserType.Teacher });
    if (admin) {
      throw new CustomError("Bad Request", 404, "Student already exist");
    }

    const user = await createUser({
      ...req.body,
      type: UserType.Student,
    });
    const token = await user.generateAuthToken();

    res.status(200).send({ user, token });
  } catch (err) {
    checkError(err, res);
  }
}

export async function loginStudentHandler(req: Request, res: Response) {
  try {
    const admin = await validatePassword({
      ...req.body,
      type: UserType.Student,
    });
    if (!admin) {
      throw new CustomError(
        "Bad request",
        404,
        "Please Provide Right Credientials"
      );
    }
    const token = await admin.generateAuthToken();

    console.log({ user: admin, token });
    res.send({ user: admin, token });
  } catch (err) {
    checkError(err, res);
  }
}

export async function logoutStudentHandler(req: Request, res: Response) {
  try {
    const token = req.header("Authorization")?.replace("Bearer ", "") as string;
    console.log("token", token);
    if (!token) {
      throw new CustomError("Bad request", 401, "Please Authenticate first");
    }
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET as string
    ) as CustomJwtPayload;
    const admin = findAndUpdateUser(
      {
        _id: decoded._id,
        tokens: token,
      },
      {
        $pull: {
          tokens: token,
        },
      },
      {}
    );

    if (!admin) {
      throw new CustomError("Bad request", 401, "Please Authenticate first");
    }

    res.send({ message: "You are successfully logout" });
  } catch (err) {
    checkError(err, res);
  }
}

export async function getStatusHandler(req: Request, res: Response) {
  try {
    res.send(req.user);
  } catch (err) {
    checkError(err, res);
  }
}

export async function dashboardHandler(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;

    const meetings = await aggregateMeeting([
      {
        $match: {
          startTime: { $gt: moment().subtract(10, "minute").toDate() },
        },
      },
      { $sort: { startTime: -1 } },

      {
        $lookup: {
          from: "users",
          let: { createdBy: "$createdBy" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [{ $eq: ["$_id", "$$createdBy"] }],
                },
              },
            },
          ],
          as: "owner",
        },
      },
      { $unwind: { path: "$owner", preserveNullAndEmptyArrays: true } },
    ]);
    const todaysMeetings = await aggregateMeeting([
      {
        $match: {
          users: user._id,
          startTime: {
            $gte: moment().startOf("day").toDate(),
            $lt: moment().endOf("day").toDate(),
          },
        },
      },
      {
        $lookup: {
          from: "meetinglogs",
          let: { meetingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$meetingId", "$$meetingId"] },
                    { $eq: ["$userId", user._id] },
                  ],
                },
              },
            },
          ],
          as: "logs",
        },
      },
    ]);
    const report = { emotion: {}, drowsy: {} };
    todaysMeetings.forEach((value) => {
      const exp = (value.logs as any[]).reduce(
        (total, value) => {
          if (total.emotion[value.emotion]) {
            total.emotion[value.emotion] += 1;
          } else {
            total.emotion[value.emotion] = 1;
          }
          if (total.drowsy[value.drowsiness]) {
            total.drowsy[value.drowsiness] += 1;
          } else {
            total.drowsy[value.drowsiness] = 1;
          }
          return total;
        },
        {
          emotion: {},
          drowsy: {},
        }
      );
      const drowsy = findMaxKey(exp.drowsy);
      const emotion = findMaxKey(exp.emotion);
      if (emotion) {
        //@ts-ignore
        if (report.emotion[emotion]) {
          //@ts-ignore
          report.emotion[emotion] += 1;
        } else {
          //@ts-ignore
          report.emotion[emotion] = 1;
        }
      }
      if (drowsy) {
        //@ts-ignore
        if (report.drowsy[drowsy]) {
          //@ts-ignore
          report.drowsy[drowsy] += 1;
        } else {
          //@ts-ignore
          report.drowsy[drowsy] = 1;
        }
      }
    });
    const allMeetings = await aggregateMeeting([
      {
        $match: {
          users: user._id,
        },
      },
      {
        $lookup: {
          from: "meetinglogs",
          let: { meetingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$meetingId", "$$meetingId"] },
                    { $eq: ["$userId", user._id] },
                  ],
                },
              },
            },
          ],
          as: "logs",
        },
      },
    ]);
    const reportAll = { emotion: {}, drowsy: {} };
    allMeetings.forEach((value) => {
      const exp = (value.logs as any[]).reduce(
        (total, value) => {
          if (total.emotion[value.emotion]) {
            total.emotion[value.emotion] += 1;
          } else {
            total.emotion[value.emotion] = 1;
          }
          if (total.drowsy[value.drowsiness]) {
            total.drowsy[value.drowsiness] += 1;
          } else {
            total.drowsy[value.drowsiness] = 1;
          }
          return total;
        },
        {
          emotion: {},
          drowsy: {},
        }
      );
      const drowsy = findMaxKey(exp.drowsy);
      const emotion = findMaxKey(exp.emotion);
      if (emotion) {
        //@ts-ignore
        if (reportAll.emotion[emotion]) {
          //@ts-ignore
          reportAll.emotion[emotion] += 1;
        } else {
          //@ts-ignore
          reportAll.emotion[emotion] = 1;
        }
      }
      if (drowsy) {
        //@ts-ignore
        if (reportAll.drowsy[drowsy]) {
          //@ts-ignore
          reportAll.drowsy[drowsy] += 1;
        } else {
          //@ts-ignore
          reportAll.drowsy[drowsy] = 1;
        }
      }
    });
    console.log("report", report, reportAll);
    res.send({
      meetings,
      emotion: reportAll.emotion,
      allMeeting: allMeetings.length,
      allEmotion: findMaxKey(reportAll.emotion),
      allDrowsy: findMaxKey(reportAll.drowsy),
      todayMeeting: todaysMeetings.length,
      todayEmotion: findMaxKey(report.emotion),
      todayDrowsy: findMaxKey(report.drowsy),
    });
  } catch (err) {
    checkError(err, res);
  }
}

export async function joinMeetingHandler(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;
    const meetings = await findAndUpdateMeeting(
      { meetingLink: req.body.meetingId, status: MeetingStatus.Pending },
      { $addToSet: { users: user._id } },
      {}
    );
    if (!meetings) {
      throw new CustomError(
        "Bad Request",
        404,
        "no such meeting found or meeting already completed"
      );
    }
    res.send({ message: "meeting successfully joined" });
  } catch (err) {
    checkError(err, res);
  }
}

export async function meetingLogHandler(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;
    const expresion = [
      "angry",
      "happy",
      "sad",
      "disgust",
      "fear",
      "neutral",
      "surprise",
    ];
    const drowsy = ["awake", "drowsy"];

    const meeting = await findMeeting({
      meetingLink: req.body.meetingId,
      users: user._id,
    });
    if (!meeting || !req.body.image) {
      throw new CustomError("Bad Reuqest", 404, "No such meeting found ");
    }

    const random = await detectEmotionAndDrowsiness(req);
    if (!random) {
      throw new CustomError("Bad Request", 404, "Some error occured");
    }
    //we get response from our secondary api which run ml model and detect emotion based on this image and
    // after detecting and again send response to our main api which store that emotion data to database
    console.log("expr", expresion?.[random?.emotionIndex] ?? "sad");
    const log = await createMeetingLog({
      meetingId: meeting._id,
      userId: user._id,
      emotion: expresion?.[random?.emotionIndex ?? 0] ?? "sad",
      drowsiness: drowsy?.[random?.drowsinessIndex ?? 0] ?? "awake",
    });
    res.send({ emotion: log.emotion });
  } catch (err) {
    checkError(err, res);
  }
}

export async function meetingDetail(req: Request, res: Response) {
  try {
    const user = req.user as UserDocument;
    const meetings = await aggregateMeeting([
      { $sort: { startTime: -1 } },
      {
        $addFields: {
          present: { $in: [user._id, "$users"] },
        },
      },
      {
        $lookup: {
          from: "meetinglogs",
          let: { meetingId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$meetingId", "$$meetingId"] },
                    { $eq: ["$userId", user._id] },
                  ],
                },
              },
            },
          ],
          as: "logs",
        },
      },
      {
        $lookup: {
          from: "users",
          let: { createdBy: "$createdBy" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [{ $eq: ["$_id", "$$createdBy"] }],
                },
              },
            },
          ],
          as: "owner",
        },
      },
      { $unwind: { path: "$owner", preserveNullAndEmptyArrays: true } },
    ]);
    res.send(meetings);
  } catch (err) {
    checkError(err, res);
  }
}
