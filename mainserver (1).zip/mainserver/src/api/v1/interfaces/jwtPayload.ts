export default interface CustomJwtPayload {
  _id: string;
}
