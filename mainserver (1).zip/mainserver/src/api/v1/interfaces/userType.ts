enum UserType {
  Teacher = "teacher",
  Student = "student",
}
export default UserType;
