export type Token = { token: string };

export default interface BaseIdentifier {
  password: string;
  createdAt: Date;
  updatedAt: Date;
  tokens: String[];
  comparePassword(password: string): Promise<boolean>;
}
